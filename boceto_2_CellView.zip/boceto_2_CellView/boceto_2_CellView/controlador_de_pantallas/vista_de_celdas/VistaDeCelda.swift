//
//  VistaDeCeldaCollectionViewCell.swift
//  boceto_2_CellView
//
//  Created by alumno on 07-10-24.
//

import UIKit

class VistaDeCelda: UICollectionViewCell {
    
    @IBOutlet weak var titulo: UILabel!
   
    @IBOutlet weak var cuerpo: UILabel!
}

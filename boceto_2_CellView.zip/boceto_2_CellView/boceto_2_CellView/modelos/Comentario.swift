//
//  Comentario.swift
//  boceto_2_CellView
//
//  Created by alumno on 21-10-24.
//

struct Comentario: Codable{
    var postId: Int
    var id: Int
    var name: String
    var email: String
    var body: String
}

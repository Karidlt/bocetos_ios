//
//  Usuarios.swift
//  boceto_2_CellView
//
//  Created by alumno on 21-10-24.
//

struct Usuario: Codable{
    var id: Int
    var name: String
    var username: String
    var email: String
}

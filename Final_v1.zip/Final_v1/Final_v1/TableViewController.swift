//
//  TableViewController.swift
//  Final_v1
//
//  Created by alumno on 08-11-24.
//

import Foundation
import UIKit

class vita_tabla: UITableViewCell {
    
}
